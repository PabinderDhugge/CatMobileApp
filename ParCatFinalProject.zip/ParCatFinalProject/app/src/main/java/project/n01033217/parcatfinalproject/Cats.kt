package project.n01033217.parcatfinalproject

class Cats {
    var cat: String? = null
    var phone : String? = null
    var last : String? = null
    var first : String? = null

    constructor(cat: String, phone : String, last: String, first: String){
        this.cat = cat
        this.phone = phone
        this.last = last
        this.first = first
    }
}