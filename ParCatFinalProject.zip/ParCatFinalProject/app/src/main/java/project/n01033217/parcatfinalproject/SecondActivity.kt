package project.n01033217.parcatfinalproject

import android.content.Context
import android.os.Bundle
import android.os.PersistableBundle
import android.util.Log
import android.view.View
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import kotlinx.android.synthetic.main.activity_second2.*
import java.io.*
import java.lang.Exception
import java.lang.StringBuilder

private const val TAG = "MyActivity"
var button = ""

class SecondActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_second2)
        if(savedInstanceState != null){
            if(button == "clicked"){
                layout.visibility = View.VISIBLE
                btnCheck.visibility = View.INVISIBLE
            }
        }

        val intent = getIntent()
        val name = intent.getStringExtra("Name")
        val gender = intent.getStringExtra("gender")
        val age = intent.getStringExtra("Age")

        tempResults.text = " Cat Chosen Is $name \n Gender is $gender \n Age is $age \n Cost: $1500"

        btnConfirm.setOnClickListener {
            val phone = editNumber.text.toString()
            val first = editFirst.text.toString()
            val last = editLast.text.toString()

            if (phone.isEmpty() || first.isEmpty() || last.isEmpty()) {
                Toast.makeText(this, "Not all fields were entered.", Toast.LENGTH_LONG).show()
            } else {
                val dbHandler = MyDBOpenHelper(this, null)
                val user = Cats(name.toString(), phone, last, first)
                dbHandler.addName(user)
                finish()
                Toast.makeText(this, "Thank You $first $last.", Toast.LENGTH_LONG).show()
            }
        }
    }

    fun Check(view: View) {
        button = "clicked"
        val dbHandler = MyDBOpenHelper(this, null)
        val cursor = dbHandler.findOne(name.toString())
        Log.i(TAG, "The cursor is " + cursor)

        if (cursor?.getCount() == 0) {
            layout.visibility = View.VISIBLE
            btnCheck.visibility = View.INVISIBLE
            Toast.makeText(this, "$name Still Available .", Toast.LENGTH_LONG).show()
        } else {
            Toast.makeText(this, "$name Is No Longer Available .", Toast.LENGTH_LONG).show()
            finish()
        }
    }

    override fun onSaveInstanceState(outState: Bundle, outPersistentState: PersistableBundle) {
        super.onSaveInstanceState(outState, outPersistentState)
        outState.putString("button", "clicked")
    }
}