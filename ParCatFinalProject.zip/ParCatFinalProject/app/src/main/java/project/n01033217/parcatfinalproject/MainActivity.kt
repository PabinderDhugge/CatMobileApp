package project.n01033217.parcatfinalproject

import android.content.Context
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.Menu
import android.view.MenuItem
import android.widget.Toast
import kotlinx.android.synthetic.main.activity_main.*
import java.io.FileNotFoundException
import java.io.FileOutputStream
import java.lang.Exception

var name = ""
var gender = ""
var age = ""

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        btnPick.setOnClickListener{
            when {
                //Makes sure Kitten is selected
                radGroup.checkedRadioButtonId == -1 -> {
                    Toast.makeText(this, "No Kitten Was Selected.", Toast.LENGTH_LONG).show()
                }
                radLyn.isChecked -> {
                    //Saves Variables for Lyn
                    name = "Lyn"
                    gender = "Female"
                    age = "8 weeks"
                    //temp results
                    val temp = "Name is : $name \n Gender is : $gender \n Age is : $age"
                    val intent = Intent(this@MainActivity, SecondActivity::class.java)
                    intent.putExtra("Name", name)
                    intent.putExtra("gender", gender)
                    intent.putExtra("Age", age)
                    startActivity(intent)
                }
                radRoy.isChecked -> {
                    //Saves Variables for Roy
                    name = "Roy"
                    gender = "Male"
                    age = "7 weeks"
                    //temp results
                    val temp = "Name is : $name \n Gender is : $gender \n Age is : $age"
                    val intent = Intent(this@MainActivity, SecondActivity::class.java)
                    intent.putExtra("Name", name)
                    intent.putExtra("gender", gender)
                    intent.putExtra("Age", age)
                    startActivity(intent)
                }
                else -> {
                    //Saves Variables for Omen
                    name = "Omen"
                    gender = "Male"
                    age = "9 weeks"
                    //temp results
                    val temp = "Name is : $name \n Gender is : $gender \n Age is : $age"
                    val intent = Intent(this@MainActivity, SecondActivity::class.java)
                    intent.putExtra("Name", name)
                    intent.putExtra("gender", gender)
                    intent.putExtra("Age", age)
                    startActivity(intent)
                }
            }
        }

        btnNotify.setOnClickListener {
            val file = "PhoneNumbers.txt"
            val data = editNumber.text.toString()

            val fileOutputStream : FileOutputStream

            if (data.isEmpty()) {
                Toast.makeText(this, "No Phone Number was Entered.", Toast.LENGTH_LONG).show()
            } else {
                try {
                    fileOutputStream = openFileOutput(file, Context.MODE_PRIVATE)
                    fileOutputStream.write(data.toByteArray())
                }
                catch (e: FileNotFoundException){
                    e.printStackTrace()
                }
                catch (e: Exception){
                    e.printStackTrace()
                }
                Toast.makeText(this, "Thank you the number ${editNumber.text} has been saved.\n You will be notified when the new kittens are born.", Toast.LENGTH_LONG).show()
                editNumber.text = null
            }
        }
    }
    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        val inflater = menuInflater
        inflater.inflate(R.menu.menu, menu)
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem) = when (item.itemId) {

        R.id.action_help -> {
            val intents = Intent(this@MainActivity, thirdactivity::class.java)
            startActivity(intents)
            true
        }
        R.id.action_about -> {
            Toast.makeText(this, "December 8th, Parbinder Dhugge N01033217", Toast.LENGTH_LONG).show()
            true
        }
        else -> {
            super.onOptionsItemSelected(item)
        }
    }
}
