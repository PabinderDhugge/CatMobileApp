package project.n01033217.parcatfinalproject

import android.content.res.Resources
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import kotlinx.android.synthetic.main.activity_help.*

class thirdactivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_help)

        editHelp.text = "This app is for cat adoption. On the main activity there are two sections, the first one is to adopt one of the 3 currently available kittens and the second is to make a be notified by phone call when the next litter is available. For the notify it works by saving the phone number in a file, while the selection of the kitten button works by taking the information on the cat that the user has selected and sending it to the second activity. Once in the second activity user will be able to check if the kitten is still available and this is done by going through a database of kittens that have already been adopted and confirming that the selected kitten has not already been adopted. If kitten is already taken an error toast will appear and take the user back to the first activity where they may select a new kitten, else after confirming that the kitten selected is still up for adoption a new text boxes will appear in place of the check button where they can enter their details which will add their information along with the selected kitten into the databasem thus reserving the kitten for them.  "

        btnBack.setOnClickListener {
            finish()
        }
    }
}